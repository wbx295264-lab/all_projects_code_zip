package com.wuxi.zhixingtravel.agent.transportation;

import com.wuxi.zhixingtravel.agent.requirement.Requirements;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @Author ccj
 */
@EqualsAndHashCode(callSuper = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TransportAssemble extends Requirements implements Serializable {
    private String drivePlan;
    private String trainPlan;
    private String flightPlan;
}
