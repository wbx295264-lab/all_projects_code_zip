package com.wuxi.zhixingtravel.model.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author ccj
 * @Description
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ConversationListResp {

    //会话id
    private String id;

    private String title;
}
