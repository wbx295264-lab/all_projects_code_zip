package com.wuxi.zhixingtravel.service;

import com.wuxi.zhixingtravel.model.dto.LoginRequest;
import com.wuxi.zhixingtravel.model.dto.RegisterRequest;
import com.wuxi.zhixingtravel.model.dto.UserInfo;

/**
 * @Author ccj
 */
public interface UserService {
    void register(RegisterRequest req);

    UserInfo login(LoginRequest req);

    void logout(String userId);
}
