package com.wuxi.zhixingtravel.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.wuxi.zhixingtravel.model.User;
import org.apache.ibatis.annotations.Mapper;

public interface UserMapper extends BaseMapper<User> {
}
