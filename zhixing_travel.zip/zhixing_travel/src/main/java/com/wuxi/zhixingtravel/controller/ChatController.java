package com.wuxi.zhixingtravel.controller;

import com.wuxi.zhixingtravel.agent.NormalService;
import com.wuxi.zhixingtravel.model.dto.ChatRequest;
import com.wuxi.zhixingtravel.service.ChatService;
import com.wuxi.zhixingtravel.utils.RequestContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;

@RestController
@RequestMapping("/travel")
public class ChatController {


    @Autowired
    private NormalService normalService;

    @Autowired
    private ChatService chatService;

    /**
     * 普通对话测试
     */
    @PostMapping(value = "/chat", produces = MediaType.TEXT_PLAIN_VALUE)
    public Flux<String> chat(@RequestBody ChatRequest chatRequest) {
        String userId = RequestContext.getUserId();
        return chatService.chat(userId, chatRequest.getSessionId(), chatRequest.getPrompt());
    }

    @PostMapping(value = "/stream/chat", produces = MediaType.TEXT_PLAIN_VALUE)
    public Flux<String> streamChat(@RequestBody ChatRequest chatRequest) {
        return chat(chatRequest);
    }

    @PostMapping(value = "/normal/stream", produces = MediaType.TEXT_PLAIN_VALUE)
    public Flux<String> normalStreamChat(@RequestBody ChatRequest chatRequest) {
        return normalService.chat(chatRequest.getSessionId(), chatRequest.getPrompt());
    }
}
