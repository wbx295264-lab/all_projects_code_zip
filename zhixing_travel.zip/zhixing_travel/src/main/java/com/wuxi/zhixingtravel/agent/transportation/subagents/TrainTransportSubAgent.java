package com.wuxi.zhixingtravel.agent.transportation.subagents;

import com.alibaba.dashscope.utils.JsonUtils;
import com.wuxi.zhixingtravel.agent.requirement.Requirements;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class TrainTransportSubAgent {

    @Autowired
    private TrainTransportSubService trainTransportSubService;

    public String execute(String sessionId, Requirements requirements) {
        String prompt = JsonUtils.toJson(requirements);
        return trainTransportSubService.chat(sessionId, prompt);
    }

}
