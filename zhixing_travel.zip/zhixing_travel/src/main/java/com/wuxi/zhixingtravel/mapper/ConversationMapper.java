package com.wuxi.zhixingtravel.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.wuxi.zhixingtravel.model.Conversation;
import org.apache.ibatis.annotations.Mapper;

public interface ConversationMapper extends BaseMapper<Conversation> {
}
