package com.wuxi.zhixingtravel.config;

import com.wuxi.zhixingtravel.agent.NormalService;
import com.wuxi.zhixingtravel.agent.accommodation.AccommodationPlannerService;
import com.wuxi.zhixingtravel.agent.food.FoodPlannerService;
import com.wuxi.zhixingtravel.agent.requirement.RequirementAgentService;
import com.wuxi.zhixingtravel.agent.transportation.TransportPlannerService;
import com.wuxi.zhixingtravel.agent.transportation.subagents.DrivingTransportSubService;
import com.wuxi.zhixingtravel.agent.transportation.subagents.FlightTransportSubService;
import com.wuxi.zhixingtravel.agent.transportation.subagents.TrainTransportSubService;
import dev.langchain4j.mcp.McpToolProvider;
import dev.langchain4j.memory.chat.MessageWindowChatMemory;
import dev.langchain4j.model.chat.ChatModel;
import dev.langchain4j.model.chat.StreamingChatModel;
import dev.langchain4j.rag.content.retriever.ContentRetriever;
import dev.langchain4j.service.AiServices;
import dev.langchain4j.store.memory.chat.ChatMemoryStore;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.ThreadPoolExecutor;

@Configuration
public class AgentFactory implements ApplicationContextAware {


    @Autowired
    private ChatModel chatModel;


    @Autowired
    private ChatMemoryStore chatMemoryStore;

    @Autowired
    private ContentRetriever contentRetriever;

    @Autowired
    private StreamingChatModel streamingChatModel;

    private ApplicationContext applicationContext;


    public <T> T getAgent(Class<T> agentClass) {
        return applicationContext.getBean(agentClass);
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }

    @Bean
    public NormalService normalService(@Qualifier("toolsNormal") McpToolProvider toolsNormal) {

        return AiServices.builder(NormalService.class)
                .chatModel(chatModel)
                .streamingChatModel(streamingChatModel)
                //memory 和 会话id 存redis
                .chatMemoryProvider(memoryId ->
                        MessageWindowChatMemory.builder()
                                .id(memoryId)
                                .chatMemoryStore(chatMemoryStore)
                                .maxMessages(1000)
                                .build()
                )
                .contentRetriever(contentRetriever)
//                .tools(new TimeTool(), ragTool, emailTool)
                .toolProvider(toolsNormal)
                .build();
    }

    @Bean
    public AccommodationPlannerService accommodationPlannerService(@Qualifier("toolsAccommodation") McpToolProvider toolsAccommodation) {
        return AiServices.builder(AccommodationPlannerService.class)
                .chatModel(chatModel)
                .streamingChatModel(streamingChatModel)
                //memory 和 会话id 存redis
                .chatMemoryProvider(memoryId ->
                        MessageWindowChatMemory.builder()
                                .id("accommodation:" + memoryId)
                                .chatMemoryStore(chatMemoryStore)
                                .maxMessages(20)
                                .build()
                )
                .contentRetriever(contentRetriever)
//                .tools(new TimeTool(), ragTool, emailTool)
                .toolProvider(toolsAccommodation)
                .build();
    }

    @Bean
    public FoodPlannerService foodPlannerService(@Qualifier("toolsFood") McpToolProvider toolsFood) {
        return AiServices.builder(FoodPlannerService.class)
                .chatModel(chatModel)
                .streamingChatModel(streamingChatModel)
                //memory 和 会话id 存redis
                .chatMemoryProvider(memoryId ->
                        MessageWindowChatMemory.builder()
                                .id("food:" + memoryId)
                                .chatMemoryStore(chatMemoryStore)
                                .maxMessages(1000)
                                .build()
                )
                .contentRetriever(contentRetriever)
//                .tools(new TimeTool(), ragTool, emailTool)
                .toolProvider(toolsFood)
                .build();
    }


    @Bean
    public TransportPlannerService transportPlannerService(@Qualifier("toolsTransportPlanner") McpToolProvider toolsTransportPlanner) {
        return AiServices.builder(TransportPlannerService.class)
                .chatModel(chatModel)
                .streamingChatModel(streamingChatModel)
                //memory 和 会话id 存redis
                .chatMemoryProvider(memoryId ->
                        MessageWindowChatMemory.builder()
                                .id("transport:" + memoryId)
                                .chatMemoryStore(chatMemoryStore)
                                .maxMessages(20)
                                .build()
                )
                .contentRetriever(contentRetriever)
//                .tools(new TimeTool(), ragTool, emailTool)
                .toolProvider(toolsTransportPlanner)
                .build();
    }

    @Bean
    public RequirementAgentService requirementAgentService(@Qualifier("toolsRequirement") McpToolProvider toolsRequirement) {
        return AiServices.builder(RequirementAgentService.class)
                .chatModel(chatModel)
                .streamingChatModel(streamingChatModel)
                .chatMemoryProvider(memoryId ->
                        MessageWindowChatMemory.builder()
                                .id("requirement:" + memoryId)
                                .chatMemoryStore(chatMemoryStore)
                                .maxMessages(20)
                                .build()
                )
                .toolProvider(toolsRequirement)
                .build();
    }


    @Bean
    public DrivingTransportSubService drivingTransportSubService(@Qualifier("toolsDriving") McpToolProvider toolsDriving) {
        return AiServices.builder(DrivingTransportSubService.class)
                .chatModel(chatModel)
                .streamingChatModel(streamingChatModel)
                //memory 和 会话id 存redis
                .chatMemoryProvider(memoryId ->
                        MessageWindowChatMemory.builder()
                                .id("driving:" + memoryId)
                                .chatMemoryStore(chatMemoryStore)
                                .maxMessages(20)
                                .build()
                )
                .contentRetriever(contentRetriever)
//                .tools(new TimeTool(), ragTool, emailTool)
                .toolProvider(toolsDriving)
                .build();
    }


    @Bean
    public FlightTransportSubService flightTransportSubService(@Qualifier("toolsFlight") McpToolProvider toolsFlight) {
        return AiServices.builder(FlightTransportSubService.class)
                .chatModel(chatModel)
                .streamingChatModel(streamingChatModel)
                //memory 和 会话id 存redis
                .chatMemoryProvider(memoryId ->
                        MessageWindowChatMemory.builder()
                                .id("flight:" + memoryId)
                                .chatMemoryStore(chatMemoryStore)
                                .maxMessages(20)
                                .build()
                )
                .contentRetriever(contentRetriever)
//                .tools(new TimeTool(), ragTool, emailTool)
                .toolProvider(toolsFlight)
                .build();
    }


    @Bean
    public TrainTransportSubService trainTransportSubService(@Qualifier("toolsTrain") McpToolProvider toolsTrain) {
        return AiServices.builder(TrainTransportSubService.class)
                .chatModel(chatModel)
                .streamingChatModel(streamingChatModel)
                //memory 和 会话id 存redis
                .chatMemoryProvider(memoryId ->
                        MessageWindowChatMemory.builder()
                                .id("train:" + memoryId)
                                .chatMemoryStore(chatMemoryStore)
                                .maxMessages(20)
                                .build()
                )
                .contentRetriever(contentRetriever)
//                .tools(new TimeTool(), ragTool, emailTool)
                .toolProvider(toolsTrain)
                .build();
    }
    
    /**
     * 核心线程数
     * 默认的核心线程数为1
     *
     */
    private static final int CORE_POOL_SIZE = 6;
    /**
     * 最大线程数
     * 默认的最大线程数是Integer.MAX_VALUE 即2<sup>31</sup>-1
     */
    private static final int MAX_POOL_SIZE = 50;
    /**
     * 缓冲队列数
     * 默认的缓冲队列数是Integer.MAX_VALUE 即2<sup>31</sup>-1
     */
    private static final int QUEUE_CAPACITY = 100;

    /**
     * 允许线程空闲时间
     * 默认的线程空闲时间为60秒
     */
    private static final int KEEP_ALIVE_SECONDS = 30;

    /**
     * 线程池前缀名
     */
    private static final String THREAD_NAME_PREFIX = "Task_Service_Async_";


    @Bean("taskExecutor")
    public ThreadPoolTaskExecutor taskExecutor() {

        ThreadPoolTaskExecutor taskExecutor = new ThreadPoolTaskExecutor();
        taskExecutor.setCorePoolSize(CORE_POOL_SIZE);
        taskExecutor.setMaxPoolSize(MAX_POOL_SIZE);
        taskExecutor.setQueueCapacity(QUEUE_CAPACITY);
        taskExecutor.setKeepAliveSeconds(KEEP_ALIVE_SECONDS);
        taskExecutor.setThreadNamePrefix(THREAD_NAME_PREFIX);
        taskExecutor.setAllowCoreThreadTimeOut(false);
        taskExecutor.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());
        //线程池初始化
        taskExecutor.initialize();
        return taskExecutor;
    }
}
