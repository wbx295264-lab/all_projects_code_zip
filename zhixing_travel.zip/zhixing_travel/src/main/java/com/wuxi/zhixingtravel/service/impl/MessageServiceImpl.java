package com.wuxi.zhixingtravel.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.wuxi.zhixingtravel.enums.CommonError;
import com.wuxi.zhixingtravel.exception.BusinessException;
import com.wuxi.zhixingtravel.mapper.ConversationMapper;
import com.wuxi.zhixingtravel.mapper.MessageMapper;
import com.wuxi.zhixingtravel.model.Conversation;
import com.wuxi.zhixingtravel.model.Message;
import com.wuxi.zhixingtravel.service.MessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @Author ccj
 * @Description
 */
@Service
public class MessageServiceImpl extends ServiceImpl<MessageMapper, Message> implements MessageService {

    @Autowired
    private ConversationMapper conversationMapper;

    @Override
    public Page<Message> pageByConversation(String userId, String conversationId, long page, long size) {
        Conversation conversation = conversationMapper.selectOne(new LambdaQueryWrapper<Conversation>()
                .eq(Conversation::getId, conversationId)
                .eq(Conversation::getUserId, userId)
                .eq(Conversation::getIsDelete, 0)
                .last("limit 1"));
        if (conversation == null) {
            throw new BusinessException(CommonError.INVALID_PARAMETER_ERROR.getCode(), "会话不存在");
        }

        long safePage = Math.max(1, page);
        long safeSize = Math.min(200, Math.max(1, size));

        Page<Message> p = new Page<>(safePage, safeSize);
        return this.lambdaQuery()
                .eq(Message::getConversationId, conversationId)
                .eq(Message::getIsDelete, 0)
                .orderByAsc(Message::getCreatedAt)
                .page(p);
    }
}
