package com.wuxi.zhixingtravel.mapper;

import org.apache.ibatis.annotations.Param;

public interface StoreMapper {

    int upsert(@Param("namespace") String[] namespace,
               @Param("key") String key,
               @Param("jsonValue") String jsonValue);
}
