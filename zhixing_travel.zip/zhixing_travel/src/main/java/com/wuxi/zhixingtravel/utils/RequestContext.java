package com.wuxi.zhixingtravel.utils;


/**
 * @Author ccj
 * @Date 2024-05-04 22:14
 * @Description
 */
public class RequestContext {

    private final static ThreadLocal<RequestContextInfo> threadLocal = new ThreadLocal<>();

    public static void set(RequestContextInfo requestHolderInfo) {
        threadLocal.set(requestHolderInfo);
    }


    public static RequestContextInfo get() {
        return threadLocal.get();
    }

    public static String getUserId() {
        return threadLocal.get().getUserId();
    }

    public static void remove() {
        threadLocal.remove();
    }

}
