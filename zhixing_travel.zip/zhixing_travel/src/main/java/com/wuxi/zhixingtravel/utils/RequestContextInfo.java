package com.wuxi.zhixingtravel.utils;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author ccj
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class RequestContextInfo {
    private String userId;
}
