package com.wuxi.zhixingtravel.service;

import reactor.core.publisher.Flux;

/**
 * @Author ccj
 * @Description
 */
public interface ChatService {
    Flux<String> chat(String userId, String sessionId, String prompt);
}
