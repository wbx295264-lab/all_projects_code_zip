package com.wuxi.zhixingtravel.agent.requirement;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;


/**
 * @Author ccj
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class RequirementInfo implements Serializable {
    private String sessionId;
    private String userText;
    private Boolean missing;
    private String firstMissing;
    private Requirements requirements; //已收集到的需求
}


