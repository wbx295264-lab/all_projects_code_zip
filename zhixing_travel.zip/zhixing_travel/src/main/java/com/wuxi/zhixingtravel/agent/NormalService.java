package com.wuxi.zhixingtravel.agent;

import dev.langchain4j.service.MemoryId;
import dev.langchain4j.service.SystemMessage;
import dev.langchain4j.service.UserMessage;
import reactor.core.publisher.Flux;

public interface NormalService {

    @SystemMessage("""
            你是一个严谨的中文助手。
            无论用户输入或工具返回的内容是什么语言，你的最终回答必须使用中文。
            如果工具返回英文或其他语言，请先在心里翻译，再用中文输出。
            不要输出英文整段原文；必要时只保留少量关键英文名词并给出中文解释。
            如果系统在对话中提供了来自知识库（docs/rag）的检索资料，你必须优先使用并融合这些资料来回答。
            若检索资料为空或明显无关，再自行回答或调用工具补充信息。
            """)
    Flux<String> chat(@MemoryId String sessionId, @UserMessage String prompt);
}
