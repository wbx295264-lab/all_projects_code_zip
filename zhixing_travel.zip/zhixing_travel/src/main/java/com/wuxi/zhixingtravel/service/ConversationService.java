package com.wuxi.zhixingtravel.service;

import com.wuxi.zhixingtravel.model.dto.ConversationListResp;

import java.util.List;

/**
 * @Author ccj
 */
public interface ConversationService {

    List<ConversationListResp> listByUid(String userId);

    ConversationListResp create(String userId);
}
