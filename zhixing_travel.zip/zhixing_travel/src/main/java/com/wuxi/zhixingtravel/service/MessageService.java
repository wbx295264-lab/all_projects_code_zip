package com.wuxi.zhixingtravel.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.wuxi.zhixingtravel.model.Message;

/**
 * @Author ccj
 * @Description
 */
public interface MessageService extends IService<Message> {
    Page<Message> pageByConversation(String userId, String conversationId, long page, long size);
}
