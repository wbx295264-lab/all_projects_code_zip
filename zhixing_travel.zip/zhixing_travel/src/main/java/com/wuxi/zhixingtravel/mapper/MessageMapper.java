package com.wuxi.zhixingtravel.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.wuxi.zhixingtravel.model.Message;

public interface MessageMapper extends BaseMapper<Message> {
}
