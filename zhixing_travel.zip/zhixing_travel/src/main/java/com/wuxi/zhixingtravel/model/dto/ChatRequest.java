package com.wuxi.zhixingtravel.model.dto;

import com.fasterxml.jackson.annotation.JsonAlias;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author ccj
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ChatRequest {

    @NotBlank(message = "会话不能为空")
    String sessionId;

    @JsonAlias({"message"})
    @NotBlank(message = "发送内容不能为空")
    String prompt;
}
